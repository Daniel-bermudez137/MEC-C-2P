
    import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Hashtable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Reloj extends JFrame {
    private JLabel hourLabel, minuteLabel, secondLabel;
    private JTextField hourField, minuteField, secondField;
    private JButton startButton, stopButton;
    private JSlider speedSlider;
    private Timer timer;
    private int speed = 1000; //milliseconds per tick (default 1 second)

    public Reloj() {
        super("Reloj");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        hourLabel = new JLabel("Hora:");
        hourField = new JTextField(2);
        hourField.setEditable(false);
        minuteLabel = new JLabel("Minuto:");
        minuteField = new JTextField(2);
        minuteField.setEditable(false);
        secondLabel = new JLabel("Segundo:");
        secondField = new JTextField(2);
        secondField.setEditable(false);

        JPanel timePanel = new JPanel();
        timePanel.add(hourLabel);
        timePanel.add(hourField);
        timePanel.add(minuteLabel);
        timePanel.add(minuteField);
        timePanel.add(secondLabel);
        timePanel.add(secondField);

        startButton = new JButton("Iniciar");
        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                startTimer();
            }
        });
        stopButton = new JButton("Detener");
        stopButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                stopTimer();
            }
        });

     speedSlider = new JSlider(JSlider.HORIZONTAL, 0, 2000, 1000);
speedSlider.addChangeListener(new ChangeListener() {
    public void stateChanged(ChangeEvent e) {
        speed = speedSlider.getValue();
        timer.setDelay(speed);
    }
});

JLabel speedLabel = new JLabel("Velocidad: ");
JLabel lessLabel = new JLabel("Más");
JLabel moreLabel = new JLabel("Menos");

JPanel buttonPanel = new JPanel();
buttonPanel.add(startButton);
buttonPanel.add(stopButton);
buttonPanel.add(speedLabel);
buttonPanel.add(lessLabel);
buttonPanel.add(speedSlider);
buttonPanel.add(moreLabel);

add(timePanel);
add(buttonPanel);

pack();
setVisible(true);

    }

    private void startTimer() {
        timer = new Timer(speed, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateTime();
            }
        });
        timer.start();
    }

    private void stopTimer() {
        if (timer != null) {
            timer.stop();
        }
    }

    private void updateTime() {
        long millis = System.currentTimeMillis();
        java.util.Date dt = new java.util.Date(millis);

        int hours = dt.getHours();
        int minutes = dt.getMinutes();
        int seconds = dt.getSeconds();

        hourField.setText(String.format("%02d", hours));
        minuteField.setText(String.format("%02d", minutes));
        secondField.setText(String.format("%02d", seconds));
    }

    public static void main(String[] args) {
        new Reloj();
    }
}
